function payView() {
    kony.print("payView");
    //loadPayView();
    var args = [1, 2, 3];
    kony.runOnMainThread(loadPayView, args);
}