var cartItems = [];
var subTotalStr = 0;
var shippingTotalStr = 0.3;
var totalStr = 0;

function addToCart() {
    var itemName = frmDetails.itemName.text;
    var itemImage = frmDetails.itemImage.src;
    var itemPrice = frmDetails.itemPrice.text;
    var itemQuantity = frmDetails.itemQuantity.selectedKey;
    if (itemQuantity == 0) itemQuantity = 1;
    alert(itemName + " added to cart");
    var item = {
        'name': itemName,
        'image': itemImage,
        'price': itemPrice,
        'quantity': itemQuantity
    };
    cartItems.push(item);
    var unitPrice = itemPrice.slice(1, itemPrice.length)
    subTotalStr = subTotalStr + (itemQuantity * parseFloat(unitPrice));
    totalStr = subTotalStr + shippingTotalStr;
}

function checkout() {
    kony.print(":::::::::");
    createAndGetContact();
    kony.print(":::::::::");
    var widgetMap = {
        label1943496613556: "name",
        label1943496615200: "price",
        label1943496617445: "quantity",
        image21943496613555: "image"
    }
    //frmCheckout1.segment219434966131.widgetDataMap = widgetMap;
    frmCheckout.segment21943496613197.widgetDataMap = widgetMap;
    frmCheckout.segment21943496613197.setData(cartItems);
    if (cartItems.length == 1) frmCheckout.label1943496617449.text = cartItems.length + " Item";
    else frmCheckout.label1943496617449.text = cartItems.length + " Items";
    frmCheckout.label1943496617456.text = "SubTotal: $" + subTotalStr;
    frmCheckout.label1943496617455.text = "Shipping Charges: $" + shippingTotalStr;
    frmCheckout.label1943496617454.text = "Total: $" + totalStr;
    //var encodedBase64String = btoa("Hello");
    //kony.print(encodedBase64String);
    frmCheckout.show();
}

function payView() {
    var args = [1, 2, 3];
    kony.runOnMainThread(loadPayView, args);
}