//Form JS File
function frmCheckout_button1943496617444_onClick_seq0(eventobject) {
    payView.call(this);
};

function addWidgetsfrmCheckout() {
    var label1943496617446 = new kony.ui.Label({
        "id": "label1943496617446",
        "isVisible": true,
        "skin": "lblNormal",
        "text": "My Cart"
    }, {
        "containerWeight": 29,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var image21943496617448 = new kony.ui.Image2({
        "id": "image21943496617448",
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "isVisible": true,
        "src": "shopping_cart.png"
    }, {
        "containerWeight": 16,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "referenceHeight": null,
        "referenceWidth": null,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var label1943496617449 = new kony.ui.Label({
        "id": "label1943496617449",
        "isVisible": true,
        "skin": "lblNormal",
        "text": null
    }, {
        "containerWeight": 31,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var hbox1943496617447 = new kony.ui.Box({
        "id": "hbox1943496617447",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 11,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    hbox1943496617447.add(
    label1943496617446, image21943496617448, label1943496617449);
    var segment21943496613197box = new kony.ui.Box({
        "id": "segment21943496613197box",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 34
    }, {});
    var segment21943496613197 = new kony.ui.SegmentedUI2({
        "groupCells": false,
        "id": "segment21943496613197",
        "isVisible": true,
        "layoutType": null,
        "Location": "[1,117]",
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": segment21943496613197box,
        "screenLevelWidget": false,
        "sectionHeaderSkin": "seg2Header",
        "sectionHeaderTemplate": hbox1943496617458,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "label1943496617461": "label1943496617461",
            "image21943496613555": "image21943496613555",
            "label1943496617460": "label1943496617460",
            "label1943496617445": "label1943496617445",
            "label1943496613556": "label1943496613556",
            "label1943496615200": "label1943496615200",
            "label1943496617459": "label1943496617459",
            "hbox1943496613330": "hbox1943496613330"
        }
    }, {
        "containerHeight": null,
        "containerWeight": 34,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image21943496613555 = new kony.ui.Image2({
        "id": "image21943496613555",
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "isVisible": true,
        "src": null
    }, {
        "containerWeight": 18,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "referenceHeight": null,
        "referenceWidth": null,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var label1943496613556 = new kony.ui.Label({
        "id": "label1943496613556",
        "isVisible": true,
        "skin": "lblNormal"
    }, {
        "containerWeight": 40,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var label1943496615200 = new kony.ui.Label({
        "id": "label1943496615200",
        "isVisible": true,
        "skin": "priceLabel"
    }, {
        "containerWeight": 17,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var label1943496617445 = new kony.ui.Label({
        "id": "label1943496617445",
        "isVisible": true,
        "skin": "quantityLabel"
    }, {
        "containerWeight": 17,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var hbox1943496613330 = new kony.ui.Box({
        "id": "hbox1943496613330",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 34,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    hbox1943496613330.add(
    image21943496613555, label1943496613556, label1943496615200, label1943496617445);
    segment21943496613197box.add(
    hbox1943496613330);
    var label1943496617456 = new kony.ui.Label({
        "id": "label1943496617456",
        "isVisible": true,
        "skin": "labelCharges",
        "text": "Label"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var label1943496617455 = new kony.ui.Label({
        "id": "label1943496617455",
        "isVisible": true,
        "skin": "labelCharges",
        "text": "Label"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var label1943496617454 = new kony.ui.Label({
        "id": "label1943496617454",
        "isVisible": true,
        "skin": "labelCharges",
        "text": "Total: $"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var button1943496617444 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1943496617444",
        "isVisible": true,
        "onClick": frmCheckout_button1943496617444_onClick_seq0,
        "skin": "applePayBtnSkin",
        "text": null
    }, {
        "containerWeight": 11,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    frmCheckout.add(
    hbox1943496617447, segment21943496613197, label1943496617456, label1943496617455, label1943496617454, button1943496617444);
};

function frmCheckoutGlobals() {
    var MenuId = [];
    frmCheckout = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmCheckout,
        "enabledForIdleTimeout": false,
        "id": "frmCheckout",
        "needAppMenu": true,
        "skin": "frm",
        "title": null
    }, {
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        },
        "retainScrollPosition": false
    });
};