function payView() {
    kony.print("payView");
    var args = [1, 2, 3];
    kony.runOnMainThread(loadPayView, args);
}