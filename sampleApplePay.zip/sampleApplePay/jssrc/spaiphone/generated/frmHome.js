//Form JS File
function frmHome_button16664216399_onClick_seq0(eventobject) {
    generateFingerPrint.call(this, eventobject);
};

function frmHome_segment214170896410_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    frmDetails.itemName.text = frmHome["segment214170896410"]["selectedItems"][0]["label1943496618"];
    frmDetails.itemImage.src = frmHome["segment214170896410"]["selectedItems"][0]["image21943496617"];
    frmDetails.itemPrice.text = frmHome["segment214170896410"]["selectedItems"][0]["label1943496616037"];
    frmDetails.show();
};

function frmHome_button1417089648_onClick_seq0(eventobject) {
    /* 
checkout.call(this);

 */
    dataConver.call(this);
};

function addWidgetsfrmHome() {
    var image21943496612127 = new kony.ui.Image2({
        "id": "image21943496612127",
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "isVisible": true,
        "src": "app_icon.png"
    }, {
        "containerWeight": 14,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "referenceHeight": null,
        "referenceWidth": null,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var label1943496612128 = new kony.ui.Label({
        "id": "label1943496612128",
        "isVisible": true,
        "skin": "lblNormal",
        "text": "APPLEKART"
    }, {
        "containerWeight": 40,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var hbox1943496612014 = new kony.ui.Box({
        "id": "hbox1943496612014",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 11,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    hbox1943496612014.add(
    image21943496612127, label1943496612128);
    var button16664216399 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button16664216399",
        "isVisible": true,
        "onClick": frmHome_button16664216399_onClick_seq0,
        "skin": "btnNormal",
        "text": "Button"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var segment214170896410box = new kony.ui.Box({
        "id": "segment214170896410box",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 34
    }, {});
    var segment214170896410 = new kony.ui.SegmentedUI2({
        "data": [{
            "label1943496616037": "$19.9",
            "label1943496618": "Avatar (Blu Ray)",
            "image21943496617": "avatar.png"
        }, {
            "label1943496616037": "$3.9",
            "label1943496618": "Avengers",
            "image21943496617": "avengers.png"
        }, {
            "label1943496616037": "$5.0",
            "label1943496618": "Beatles",
            "image21943496617": "beatles.png"
        }, {
            "label1943496616037": "$7.6",
            "label1943496618": "Cinderella",
            "image21943496617": "cinderella.png"
        }, {
            "label1943496616037": "$17.2",
            "label1943496618": "Kingsman",
            "image21943496617": "kingsman.png"
        }, {
            "label1943496616037": "$15.5",
            "label1943496618": "StarWars",
            "image21943496617": "starwars.png"
        }, {
            "label1943496616037": "$4.5",
            "label1943496618": "Thor",
            "image21943496617": "thor.png"
        }, {
            "label1943496616037": "$2.0",
            "label1943496618": "Avatar",
            "image21943496617": "avatar.png"
        }, {
            "label1943496616037": "$19.9",
            "label1943496618": "Big Hero 6",
            "image21943496617": "bighero.png"
        }, {
            "label1943496616037": "$3.6",
            "label1943496618": "Despicable Me 2",
            "image21943496617": "despicableme.png"
        }, {
            "label1943496616037": "$10.0",
            "label1943496618": "Furious7",
            "image21943496617": "furious7.png"
        }, {
            "label1943496616037": "$3.7",
            "label1943496618": "Hobbit",
            "image21943496617": "hobbit.png"
        }, {
            "label1943496616037": "$4.6",
            "label1943496618": "Interstellar",
            "image21943496617": "interstellar.png"
        }, {
            "label1943496616037": "$7.8",
            "label1943496618": "Jurassic Park",
            "image21943496617": "jurassicpark.png"
        }, {
            "label1943496616037": "$21.2",
            "label1943496618": "Hobbit (Blu Ray)",
            "image21943496617": "hobbit.png"
        }],
        "groupCells": false,
        "id": "segment214170896410",
        "isVisible": true,
        "layoutType": null,
        "Location": "[1,191]",
        "onRowClick": frmHome_segment214170896410_onRowClick_seq0,
        "retainSelection": false,
        "rowFocusSkin": "seg2Focus",
        "rowSkin": "seg2Normal",
        "rowTemplate": segment214170896410box,
        "screenLevelWidget": false,
        "sectionHeaderSkin": "seg2Header",
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "separatorColor": "64646400",
        "separatorRequired": true,
        "separatorThickness": 1,
        "showScrollbars": false,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "widgetDataMap": {
            "label1943496616037": "label1943496616037",
            "label1943496618": "label1943496618",
            "hbox1943496616": "hbox1943496616",
            "image21943496617": "image21943496617"
        }
    }, {
        "containerHeight": null,
        "containerWeight": 34,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {});
    var image21943496617 = new kony.ui.Image2({
        "id": "image21943496617",
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "isVisible": true,
        "src": null
    }, {
        "containerWeight": 12,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "referenceHeight": null,
        "referenceWidth": null,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var label1943496618 = new kony.ui.Label({
        "id": "label1943496618",
        "isVisible": true,
        "skin": "itemLabel"
    }, {
        "containerWeight": 40,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var label1943496616037 = new kony.ui.Label({
        "id": "label1943496616037",
        "isVisible": true,
        "skin": "lblNormal"
    }, {
        "containerWeight": 40,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var hbox1943496616 = new kony.ui.Box({
        "id": "hbox1943496616",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 34,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    hbox1943496616.add(
    image21943496617, label1943496618, label1943496616037);
    segment214170896410box.add(
    hbox1943496616);
    var button1417089648 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1417089648",
        "isVisible": true,
        "onClick": frmHome_button1417089648_onClick_seq0,
        "skin": "addToCartSkin",
        "text": "Checkout"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    frmHome.add(
    hbox1943496612014, button16664216399, segment214170896410, button1417089648);
};

function frmHomeGlobals() {
    var MenuId = [];
    frmHome = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmHome,
        "enabledForIdleTimeout": false,
        "id": "frmHome",
        "needAppMenu": true,
        "skin": "frm",
        "title": null
    }, {
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        },
        "retainScrollPosition": false
    });
};