//Template File
function hdr1_vbox14170896417_onClick_seq0(eventobject) {
    frmDetails.show();
};

function initializehdr1() {
    hbox14170896413 = new kony.ui.Box({
        "id": "hbox14170896413",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 5,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});

    function addWidgetshbox14170896413() {
        var image214170896414 = new kony.ui.Image2({
            "id": "image214170896414",
            "imageWhenFailed": null,
            "imageWhileDownloading": null,
            "isVisible": true,
            "src": "app_icon.png"
        }, {
            "containerWeight": 5,
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "margin": [0, 0, 0, 0],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "referenceHeight": null,
            "referenceWidth": null,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {});
        var label14170896415 = new kony.ui.Label({
            "id": "label14170896415",
            "isVisible": true,
            "skin": "lblNormal",
            "text": "MyKart"
        }, {
            "containerWeight": 40,
            "contentAlignment": constants.CONTENT_ALIGN_CENTER,
            "hExpand": true,
            "margin": [0, 0, 0, 0],
            "marginInPixel": false,
            "padding": [1, 1, 1, 1],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {
            "textCopyable": false
        });
        var label19434966110 = new kony.ui.Label({
            "id": "label19434966110",
            "isVisible": true,
            "skin": "lblNormal",
            "text": "0"
        }, {
            "containerWeight": 47,
            "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
            "hExpand": true,
            "margin": [0, 0, 0, 0],
            "marginInPixel": false,
            "padding": [1, 1, 1, 1],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {
            "textCopyable": false
        });
        var image214170896419 = new kony.ui.Image2({
            "id": "image214170896419",
            "imageWhenFailed": null,
            "imageWhileDownloading": null,
            "isVisible": true,
            "src": "shopping_cart.png"
        }, {
            "containerWeight": 18,
            "imageScaleMode": constants.IMAGE_SCALE_MODE_FIT_TO_DIMENSIONS,
            "margin": [0, 0, 0, 0],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "referenceHeight": null,
            "referenceWidth": null,
            "widgetAlignment": constants.WIDGET_ALIGN_CENTER
        }, {});
        var vbox14170896417 = new kony.ui.Box({
            "id": "vbox14170896417",
            "isVisible": true,
            "onClick": hdr1_vbox14170896417_onClick_seq0,
            "orientation": constants.BOX_LAYOUT_VERTICAL
        }, {
            "containerWeight": 23,
            "hExpand": true,
            "layoutType": constants.CONTAINER_LAYOUT_BOX,
            "margin": [0, 0, 0, 0],
            "marginInPixel": false,
            "padding": [0, 0, 0, 0],
            "paddingInPixel": false,
            "vExpand": false,
            "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
        }, {});
        vbox14170896417.add(
        label19434966110, image214170896419);
        hbox14170896413.add(
        image214170896414, label14170896415, vbox14170896417);
    }
    addWidgetshbox14170896413();
};