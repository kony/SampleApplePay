//GlobalSequences File
function generateFingerPrint(eventobject) {
    var params = {};
    params["serviceID"] = "TestSer";
    params["nameStr"] = "XXXXX";
    params["dataValueStr"] = "YYYYY";
    params["httpheaders"] = {
        "Content-Type": "text/xml"
    };
    //params["httpconfig"] = {};
    //TestSer = appmiddlewareinvokerasync(params, asyncCallback);
    var url = "http://10.10.1.60:8080/middleware/MWServlet"
    kony.net.invokeServiceAsync(url, params, asyncCallback);
};

function asyncCallback(status, result) {
    kony.print("Result is -->" + JSON.stringify(result));
    if (status == 400) kony.print("$#." + JSON.stringify(result));
    else kony.print("Failed to subscribe to KPNS Server!!");
}