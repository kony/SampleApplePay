//GlobalSequences File
function test_button16664216398_onClick_seq0(eventobject) {
    var TestSer_inputparam = {};
    TestSer_inputparam["serviceID"] = "TestSer";
    TestSer_inputparam["nameStr"] = test.button16664216398.text;
    TestSer_inputparam["dataValueStr"] = test.button16664216398.text;
    TestSer_inputparam["httpheaders"] = {};
    TestSer_inputparam["httpconfig"] = {};
    TestSer = appmiddlewareinvokerasync(TestSer_inputparam, test_button16664216398_onClick_seq1);
};