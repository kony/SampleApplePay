//Form JS File
function test_button16664216398_onClick_seq0(eventobject) {
    var TestSer_inputparam = {};
    TestSer_inputparam["serviceID"] = "TestSer";
    TestSer_inputparam["nameStr"] = test.button16664216398.text;
    TestSer_inputparam["dataValueStr"] = test.button16664216398.text;
    TestSer_inputparam["httpheaders"] = {};
    TestSer_inputparam["httpconfig"] = {};
    TestSer = appmiddlewareinvokerasync(TestSer_inputparam, test_button16664216398_onClick_seq1);
};

function addWidgetstest() {
    var button16664216398 = new kony.ui.Button({
        "id": "button16664216398",
        "isVisible": true,
        "text": "Button",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": test_button16664216398_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    test.add(
    button16664216398);
};

function testGlobals() {
    var MenuId = [];
    test = new kony.ui.Form2({
        "id": "test",
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "frm",
        "addWidgets": addWidgetstest
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {
        "retainScrollPosition": false,
        "needsIndicatorDuringPostShow": true,
        "formTransparencyDuringPostShow": "100",
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "bounces": true,
        "configureExtendTop": false,
        "configureExtendBottom": false,
        "configureStatusBarStyle": false,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        }
    });
};