/*window = UIWindow.jsnew();
window.frame = UIScreen.mainScreen().bounds;
window.backgroundColor = UIColor.whiteColor();*/
function encode_utf8(s) {
    return unescape(encodeURIComponent(s));
}
var addressGlobal;

function loadPayView(arg1, arg2, arg3) {
    var paymentNetworkTypes = [PKPaymentNetworkAmex, PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
    var PayViewController = objc.newClass('PayViewController', 'UIViewController', ['PKPaymentAuthorizationViewControllerDelegate'], {
        viewDidLoad: function() {
            kony.print("PayViewController viewDidLoad: " + PKPaymentAuthorizationViewController.canMakePayments());
            if ((PKPaymentAuthorizationViewController.canMakePayments())) {
                kony.print("This device is authorised to make Payments");
            } else {
                alert("This device is not authorised to make Payments");
                return;
            }
            if ((PKPaymentAuthorizationViewController.canMakePaymentsUsingNetworks(paymentNetworkTypes))) {
                kony.print("This device is authorised to make Payments on given networks");
            } else {
                alert("This device is not authorised to make Payments");
                return;
            }
            //subtotal = NSDecimalNumber.decimalNumberWithString("0.005");
            //shippingTotal = NSDecimalNumber.decimalNumberWithString("0.004");
            kony.print("shippingMethod1 :1");
            subTotal = NSDecimalNumber.decimalNumberWithString(subTotalStr.toFixed(2));
            shippingTotal = NSDecimalNumber.decimalNumberWithString(shippingTotalStr.toFixed(2));
            total = NSDecimalNumber.decimalNumberWithString(totalStr.toFixed(2));
            kony.print("shippingMethod1 :2");
            var request = PKPaymentRequest.alloc().jsinit();
            request.supportedNetworks = paymentNetworkTypes;
            request.countryCode = "US"
            request.currencyCode = "USD"
            request.merchantIdentifier = "merchant.com.kony.applepay";
            request.merchantCapabilities = PKMerchantCapabilityEMV; // || PKMerchantCapability3DS;
            //request.shippingAddress = 
            // Optional Apple Pay parameter - Send a sample application data payload
            var appDataString = "RefCode:12345; TxID:34234089240982304823094823432";
            var appData = NSData.alloc().initWithBase64Encoding(appDataString);
            kony.print("shippingMethod1 :2.1");
            request.applicationData = appData;
            kony.print("shippingMethod1 :2.3");
            /* var subtotalValue = NSDecimalNumber.decimalNumberWithString(subTotal);
                var shippingTotalValue = NSDecimalNumber.decimalNumberWithString(shippingTotal);
                var totalValue = NSDecimalNumber.decimalNumberWithString(total);*/
            var subtotalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Subtotal", subTotal);
            var shippingItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Shipping", shippingTotal);
            var totalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Total", total);
            var items = [subtotalItem, shippingItem, totalItem];
            request.paymentSummaryItems = items;
            request.requiredBillingAddressFields = PKAddressFieldAll;
            request.requiredShippingAddressFields = PKAddressFieldAll;
            //request.requiredShippingAddressFields = PKAddressFieldName;
            //var error = NSError.alloc().init();
            kony.print("shippingMethod1 :3" + addressGlobal);
            request.shippingAddress = addressGlobal;
            var shippingMethod1 = PKShippingMethod.alloc().jsinit();
            shippingMethod1.amount = NSDecimalNumber.decimalNumberWithString("0.005"); //$0.005
            shippingMethod1.label = "UPS";
            shippingMethod1.identifier = "UPS";
            shippingMethod1.detail = "3 Day Ground";
            kony.print("shippingMethod1 :4");
            var shippingMethod2 = PKShippingMethod.alloc().jsinit();
            kony.print("shippingMethod1 :5");
            shippingMethod2.amount = NSDecimalNumber.decimalNumberWithString("0.009"); //$0.009
            shippingMethod2.label = "USPS";
            shippingMethod2.identifier = "USPS";
            shippingMethod2.detail = "5-7 Days";
            var shippingMethods = [shippingMethod1, shippingMethod2];
            request.shippingMethods = shippingMethods;
            kony.print("shippingMethod1 :" + shippingMethod1.amount);
            //Create the view controller that will show the user the Apple Pay screen.
            vc = PKPaymentAuthorizationViewController.alloc().initWithPaymentRequest(request);
            vc.delegate = this;
            //You may notice that PKPaymentAuthorizationViewController shows itself whether you
            //call this or not, but if you don't call it there will be unexpected behavior.
            UIApplication.sharedApplication().keyWindow.rootViewController.presentViewControllerAnimatedCompletion(vc, true, function() {
                kony.print("View Controller Shown")
            });
        },
        viewWillAppear: function(animated) {
            kony.print("viewWillappear");
            //this.presentViewControllerAnimatedCompletion(vc, true, null);
        },
        viewWillDisappear: function(animated) {
            kony.print("viewWillDisappear");
        },
        paymentAuthorizationViewControllerDidAuthorizePaymentCompletion: function(controller, payment, completion) {
            kony.print("paymentAuthorizationViewControllerDidAuthorizePaymentCompletion: " + controller);
            //The user approved the transaction.  Time to send the transaction to the Gateway
            //for authorization.
            kony.print("Payment was authorized");
            //Most merchants will want to send the transaction data to their own server before
            //forwarding to the Gateway so that you will have the transaction information and be
            //aware of whether the transaction succeeded.  For this simple example, though, we
            //will just send the data straight to the Gateway via the Direct Post API.
            //Replace these with your own credentials
            var username = "demo";
            var password = "password";
            var transactionType = "sale";
            //paymentData is an NSData object.  It needs to be converted to a hex string to be able
            //to send it to the Gateway.
            //var applePayPaymentData = hexStringFromData(payment.token.paymentData); //Doubt
            //var postString = NSString.stringWithFormat("username=%@&password=%@&type=%@&amount=%@&applepay_payment_data=%@", username, password, transactionType, this.total(), applePayPaymentData);
            kony.print("Sending data to Gateway: %@ " + payment.token.paymentData);
            send_request(payment.token.paymentData.base64Encoding(), completion);
            //Keep the completion callback function.
            //Once we get a response from the server, we'll use it to report success or failure back
            //to PassKit.
            //this.completionCallback = completion;
        },
        paymentAuthorizationViewControllerDidFinish: function(controller) {
            kony.print("paymentAuthorizationViewControllerDidFinish: " + controller);
            //This message is sent when the payment authorization form disappears, either after
            //the user cancels or after the payment is completed.
            UIApplication.sharedApplication().keyWindow.rootViewController.dismissViewControllerAnimatedCompletion(true, function() {
                kony.print("View Controller Dismissed")
            });
        },
        paymentAuthorizationViewControllerDidSelectShippingMethodCompletion: function(controller, shippingmethod, completion) {
            kony.print("paymentAuthorizationViewControllerDidSelectShippingMethodCompletion");
            //This message is sent when the user changes their shipping method.
            //This is an opportunity to recalculate the total.
            kony.print("Shipping method changed to: " + shippingmethod.identifier);
            kony.print("subTotalStr is : " + subTotalStr);
            subTotal = NSDecimalNumber.decimalNumberWithString(subTotalStr);
            var methodShippingTotal = "0";
            if (shippingmethod.identifier == "UPS") {
                kony.print("shippingTotal is : IF");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.03");
            } else if (shippingmethod.identifier == "USPS") {
                kony.print("shippingTotal is : ELSE IF");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.01");
            } else {
                kony.print("shippingTotal is : ELSE");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.06");
            }
            kony.print("methodShippingTotal is : " + methodShippingTotal.stringValue);
            //sssss.decimalNumberByAdding(shippingTotal);
            //subtotal.decimalNumberByAdding(shippingTotal);
            //Add up the shipping and subtotal to get the amount that will be charged.
            total = subTotal.decimalNumberByAdding(methodShippingTotal);
            kony.print("total is : " + total.stringValue);
            var subtotalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Subtotal", subTotal);
            var shippingItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Shipping", methodShippingTotal);
            var totalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Total", total);
            //var summaryItems = NSMutableArray.arrayWithObjects(subtotalItem,shippingItem,totalItem, null);
            var summaryItems = [subtotalItem, shippingItem, totalItem];
            //Pass the new summary items back to the controller using the completion function.
            completion(PKPaymentAuthorizationStatusSuccess, summaryItems);
            kony.print("Completion is invoked :" + summaryItems[0].amount.stringValue);
        }
        /*, paymentAuthorizationViewControllerDidSelectShippingAddressCompletion: function(controller, address, completion) {
    		// The customer is selecting the shipping address information.
    		// You may need to keep track of the new shipping address.
    		kony.print(".....ViewController:didSelectShippingAddress invoked");
    		//kony.print(address);
		}*/
    });
    payViewController = PayViewController.jsnew();
    var x = payViewController.view;
}

function createAndGetContact() {
    kony.print("1");
    var addressBook = KonyAddressBookWrapper.ABAddressBookCreate(); // create address book record
    kony.print("2" + addressBook);
    //var x = [MyAddressBookExternalChangeCallback, this];
    var context = [1, 2, 3];
    KonyAddressBookWrapper.ABAddressBookRequestAccessWithCompletionCompletion(addressBook, function auth(bool, error) {
        kony.print("auth");
        kony.print(bool);
        person = KonyAddressBookWrapper.ABPersonCreate(); // create a person
        kony.print(person);
        /* var request = PKPaymentRequest.alloc().jsinit();
                          request.supportedNetworks = [PKPaymentNetworkAmex, PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
                          request.countryCode = "US"
                          request.currencyCode = "USD"
                          request.merchantIdentifier = "merchant.com.kony.applepay";
                          request.merchantCapabilities = PKMerchantCapability3DS;
 
                          
                          request.requiredBillingAddressFields = PKAddressFieldAll;
                          request.requiredShippingAddressFields = PKAddressFieldAll;
                          var shippingMethod1 = PKShippingMethod.alloc().jsinit();
                          shippingMethod1.amount = NSDecimalNumber.decimalNumberWithString("0.005"); //$0.005
                          shippingMethod1.label = "UPS";
                          
                          print("Shipping address");
                          print(request.shippingAddress);*/
        var phone = "0123456789"; // the phone number to add
        var firstname = "SampleName";
        var lastname = "Myname";
        KonyAddressBookWrapper.ABRecordSetValuePropertyValueError(person, kABPersonFirstNameProperty, firstname, null);
        KonyAddressBookWrapper.ABRecordSetValuePropertyValueError(person, kABPersonLastNameProperty, lastname, null);
        var x;
        var addRec = KonyAddressBookWrapper.ABAddressBookAddRecordRecordError(addressBook, person, null); //add the new person to the record
        var saveRec = KonyAddressBookWrapper.ABAddressBookSaveError(addressBook, null); //save the record
        kony.print("4" + addRec);
        // request.shippingAddress = person;
        var recId = KonyAddressBookWrapper.ABRecordGetRecordID(person);
        kony.print(recId);
        var recType = KonyAddressBookWrapper.ABRecordGetRecordType(addRec);
        kony.print("5" + recType);
        var phoneNumberMultiValue = KonyAddressBookWrapper.ABMultiValueCreateMutable(2);
        addressGlobal = person;
        kony.print("5" + addressGlobal);
        //var phone = "990983333";
        /*var outprop = 100;
      KonyAddressBookWrapper.ABMultiValueAddValueAndLabelValueLabelOutIdentifier(phoneNumberMultiValue,phone,kABPersonPhoneMobileLabel,outprop);
      print("Snigdha");
      print(outprop);*/
    });
}

function completionCallback(status) {
    kony.print("Status: " + status);
}
//var request = null;
var callbackCompletionRes = null;

function send_request(paymentData, completion) {
    kony.print("paymentData: " + paymentData);
    var request = new kony.net.HttpRequest();
    request_global_scope = request;
    //BGtransfer
    var bgTransfer = request.backgroundTransfer;
    if (bgTransfer == true) {
        kony.print(" request.backgroundTransfer: true");
    } else {
        kony.print(" request.backgroundTransfer: false");
    }
    //session
    var req_session = request.getSession();
    request.onReadyStateChange = log_onreadycallback_2;
    kony.print(" request.getSession() : " + req_session);
    //url
    //var url = "http://10.10.24.34:7001/kpns/subscription";
    var url = "https://api.authorize.net/xml/v1/request.api";
    kony.print("URL : " + url);
    request.open(constants.HTTP_METHOD_POST, url);
    request.setRequestHeader("Content-Type", "text/xml");
    var loginId = '2bj45PBe';
    var transKey = '83d7fn4R8R2rR4HX';
    var dataXml = "<createTransactionRequest  xmlns='AnetApi/xml/v1/schema/AnetApiSchema.xsd'><merchantAuthentication><name>" + loginId + "</name><transactionKey>" + transKey + "</transactionKey></merchantAuthentication><refId>123456</refId><transactionRequest><transactionType>authCaptureTransaction</transactionType><amount>1.1</amount><payment><opaqueData><dataDescriptor>FID=COMMON.APPLE.INAPP.PAYMENT</dataDescriptor><dataValue>" + paymentData + "</dataValue></opaqueData></payment><lineItems><lineItem><itemId>1</itemId><name>vase</name><description>Cannes logo </description><quantity>18</quantity><unitPrice>45.00</unitPrice></lineItem></lineItems><tax><amount>0.06</amount><name>level2 tax name</name><description>level2 tax</description></tax><duty><amount>0.05</amount><name>duty name</name><description>duty description</description></duty><shipping><amount>0.04</amount><name>level2 tax name</name><description>level2tax</description></shipping><poNumber>456654</poNumber><billTo><firstName>Ellen</firstName><lastName>Johnson</lastName><company>Souveniropolis</company><address>14MainStreet</address><city>PecanSprings</city><state>TX</state><zip>44628</zip><country>USA</country></billTo><shipTo><firstName>China</firstName><lastName>Bayles</lastName><company>ThymeforTea</company><address>12MainStreet</address><city>PecanSprings</city><state>TX</state><zip>44628</zip><country>USA</country></shipTo><customerIP>192.168.1.1</customerIP><transactionSettings><setting><settingName>testRequest</settingName><settingValue>false</settingValue></setting></transactionSettings><userFields><userField><name>MerchantDefinedFieldName1</name><value>MerchantDefinedFieldValue1</value></userField><userField><name>favorite_color</name><value>blue</value></userField></userFields></transactionRequest></createTransactionRequest>";
    //var dataXml = "<subscriptionService> <subscribe> <appId>AppForAll1</appId> <deviceId>352900053433913</deviceId> <ufid>ios1@appForall.com</ufid> <sid>APA91bFy66xDV7eP6ggX11CxvX0KTnvqmHJ7egVuAZVNuoZAM9fBz3yehKkmBkP3FNLmOgfIHwCg5jKZsgwN7oBTiWSJr5Jay6fZZzFip4UVhi-YpnzkQR4tQCClRr6unc7cLK40L9idTGrdm7QVNgE9iwpXdOr8cw</sid> <osType>androidgcm</osType> </subscribe> </subscriptionService>";
    var httpinputparams1 = new kony.net.FormData();
    dataXml = encode_utf8(dataXml);
    kony.print(" dataXml: " + dataXml);
    httpinputparams1.append("name_", dataXml);
    request.send(httpinputparams1);
    callbackCompletionRes = completion;
    //kony.print( " request.readyState : " + request.readyState);
};

function log_onreadycallback_2(request) {
    kony.print(" : +++++++++++++++++++++++++++++");
    kony.print(" : Scope :- request.readyState : " + request.readyState);
    if (constants.HTTP_READY_STATE_DONE == request.readyState) {
        kony.print(" : Scope :- callbackCompletionRes : " + callbackCompletionRes);
        //kony.print(" : Scope :- request.statusText : " + request.statusText);
        //kony.print(" : Scope :- request.responseType : " + request.responseType);
        kony.print(" : Scope :- request.response : ");
        kony.print(request.response);
        callbackCompletionRes(PKPaymentAuthorizationStatusSuccess);
    }
};

function base64_encode(data) {
    //  discuss at: http://phpjs.org/functions/base64_encode/
    // original by: Tyler Akins (http://rumkin.com)
    // improved by: Bayron Guevara
    // improved by: Thunder.m
    // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // improved by: Kevin van Zonneveld (http://kevin.vanzonneveld.net)
    // improved by: Rafał Kukawski (http://kukawski.pl)
    // bugfixed by: Pellentesque Malesuada
    //   example 1: base64_encode('Kevin van Zonneveld');
    //   returns 1: 'S2V2aW4gdmFuIFpvbm5ldmVsZA=='
    //   example 2: base64_encode('a');
    //   returns 2: 'YQ=='
    var b64 = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=';
    var o1, o2, o3, h1, h2, h3, h4, bits, i = 0,
        ac = 0,
        enc = '',
        tmp_arr = [];
    if (!data) {
        return data;
    }
    do { // pack three octets into four hexets
        o1 = data.charCodeAt(i++);
        o2 = data.charCodeAt(i++);
        o3 = data.charCodeAt(i++);
        bits = o1 << 16 | o2 << 8 | o3;
        h1 = bits >> 18 & 0x3f;
        h2 = bits >> 12 & 0x3f;
        h3 = bits >> 6 & 0x3f;
        h4 = bits & 0x3f;
        // use hexets to index into b64, and append result to encoded string
        tmp_arr[ac++] = b64.charAt(h1) + b64.charAt(h2) + b64.charAt(h3) + b64.charAt(h4);
    } while (i < data.length);
    enc = tmp_arr.join('');
    var r = data.length % 3;
    return (r ? enc.slice(0, r - 3) : enc) + '==='.slice(r || 3);
}