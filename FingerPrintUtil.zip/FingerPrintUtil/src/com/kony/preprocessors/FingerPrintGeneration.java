package com.kony.preprocessors;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;

import javax.crypto.KeyGenerator;
import javax.crypto.Mac;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;

import org.apache.log4j.Logger;

import com.konylabs.middleware.common.DataPreProcessor;
import com.konylabs.middleware.controller.DataControllerRequest;
import com.konylabs.middleware.dataobject.Result;

public class FingerPrintGeneration implements DataPreProcessor {
	private static Logger logger = Logger
			.getLogger(FingerPrintGeneration.class);
	public boolean execute(HashMap inputMap, DataControllerRequest request,
			Result result) throws Exception {

		// the parameters for the payment can be configured here
		// the API Login ID and Transaction Key must be replaced with valid
		// values
		String loginID = "apiLoginID";
		String transactionKey = "transactionKey";
		// String amount = "0.02";

		Date myDate = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyyMMddHHmmss");
		// a sequence number is randomly generated
		Random generator = new Random();
		int sequence = generator.nextInt(1000);
		// a timestamp is generated
		long timeStamp = System.currentTimeMillis() / 1000;

		// This section uses Java Cryptography functions to generate a
		// fingerprint
		// First, the Transaction key is converted to a "SecretKey" object
		KeyGenerator kg = KeyGenerator.getInstance("HmacMD5");
		SecretKey key = new SecretKeySpec(transactionKey.getBytes(), "HmacMD5");
		// A MAC object is created to generate the hash using the HmacMD5
		// algorithm
		Mac mac = Mac.getInstance("HmacMD5");
		mac.init(key);
		String inputstring = loginID + "^" + sequence + "^" + timeStamp + "^"
				+ inputMap.get("amountStr") + "^";
		byte[] resultBytes = mac.doFinal(inputstring.getBytes());
		// Convert the result from byte[] to hexadecimal format
		StringBuffer strbuf = new StringBuffer(resultBytes.length * 2);
		for (int i = 0; i < resultBytes.length; i++) {
			if (((int) resultBytes[i] & 0xff) < 0x10)
				strbuf.append("0");
			strbuf.append(Long.toString((int) resultBytes[i] & 0xff, 16));
		}
		String fingerprint = strbuf.toString();
		// end of fingerprint generation

		Iterator it = inputMap.entrySet().iterator();
		while (it.hasNext()) {
			Map.Entry pair = (Map.Entry) it.next();
			logger.error("Params: " + pair.getKey() + " = " + pair.getValue());
		}

		// update the values in the payload.
		inputMap.put("seq", String.valueOf(sequence));
		inputMap.put("stamp", "" + String.valueOf(timeStamp));
		inputMap.put("hashValueStr", fingerprint);
		inputMap.put("nameStr", loginID);

		return true;
	}
}