//Form JS File
function test_button16664216398_onClick_seq0(eventobject) {
    var TestSer_inputparam = {};
    TestSer_inputparam["serviceID"] = "TestSer";
    TestSer_inputparam["nameStr"] = test.button16664216398.text;
    TestSer_inputparam["dataValueStr"] = test.button16664216398.text;
    TestSer_inputparam["httpheaders"] = {};
    TestSer_inputparam["httpconfig"] = {};
    TestSer = appmiddlewareinvokerasync(TestSer_inputparam, test_button16664216398_onClick_seq1);
};

function addWidgetstest() {
    var button16664216398 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button16664216398",
        "isVisible": true,
        "onClick": test_button16664216398_onClick_seq0,
        "skin": "btnNormal",
        "text": "Button"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    test.add(
    button16664216398);
};

function testGlobals() {
    var MenuId = [];
    test = new kony.ui.Form2({
        "addWidgets": addWidgetstest,
        "enabledForIdleTimeout": false,
        "id": "test",
        "needAppMenu": true,
        "skin": "frm",
        "title": null
    }, {
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        },
        "retainScrollPosition": false
    });
};