//Form JS File
function frmHome_button16664216399_onClick_seq0(eventobject) {
    generateFingerPrint.call(this, eventobject);
};

function frmHome_segment214170896410_onRowClick_seq0(eventobject, sectionNumber, rowNumber) {
    frmDetails.itemName.text = frmHome["segment214170896410"]["selectedItems"][0]["label1943496618"];
    frmDetails.itemImage.src = frmHome["segment214170896410"]["selectedItems"][0]["image21943496617"];
    frmDetails.itemPrice.text = frmHome["segment214170896410"]["selectedItems"][0]["label1943496616037"];
    frmDetails.show();
};

function frmHome_button1417089648_onClick_seq0(eventobject) {
    /* 
checkout.call(this);

 */
    dataConver.call(this);
};

function addWidgetsfrmHome() {
    var image21943496612127 = new kony.ui.Image2({
        "id": "image21943496612127",
        "isVisible": true,
        "src": "app_icon.png",
        "imageWhenFailed": null,
        "imageWhileDownloading": null
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "referenceWidth": null,
        "referenceHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 14
    }, {
        "glossyEffect": constants.IMAGE_GLOSSY_EFFECT_DEFAULT
    });
    var label1943496612128 = new kony.ui.Label({
        "id": "label1943496612128",
        "isVisible": true,
        "text": "APPLEKART",
        "skin": "lblNormal"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 40
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var hbox1943496612014 = new kony.ui.Box({
        "id": "hbox1943496612014",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 11,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hbox1943496612014.add(
    image21943496612127, label1943496612128);
    var button16664216399 = new kony.ui.Button({
        "id": "button16664216399",
        "isVisible": true,
        "text": "Button",
        "skin": "btnNormal",
        "focusSkin": "btnFocus",
        "onClick": frmHome_button16664216399_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    var segment214170896410box = new kony.ui.Box({
        "id": "segment214170896410box",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_VERTICAL
    }, {
        "layoutAlignment": constants.BOX_LAYOUT_ALIGN_FROM_LEFT,
        "containerWeight": 34
    }, {});
    var segment214170896410 = new kony.ui.SegmentedUI2({
        "id": "segment214170896410",
        "isVisible": true,
        "retainSelection": false,
        "widgetDataMap": {
            "label1943496616037": "label1943496616037",
            "label1943496618": "label1943496618",
            "hbox1943496616": "hbox1943496616",
            "image21943496617": "image21943496617"
        },
        "data": [{
            "label1943496616037": "$19.9",
            "label1943496618": "Avatar (Blu Ray)",
            "image21943496617": "avatar.png"
        }, {
            "label1943496616037": "$0.1",
            "label1943496618": "Avengers",
            "image21943496617": "avengers.png"
        }, {
            "label1943496616037": "$0.01",
            "label1943496618": "Beatles",
            "image21943496617": "beatles.png"
        }, {
            "label1943496616037": "$7.6",
            "label1943496618": "Cinderella",
            "image21943496617": "cinderella.png"
        }, {
            "label1943496616037": "$17.2",
            "label1943496618": "Kingsman",
            "image21943496617": "kingsman.png"
        }, {
            "label1943496616037": "$15.5",
            "label1943496618": "StarWars",
            "image21943496617": "starwars.png"
        }, {
            "label1943496616037": "$4.5",
            "label1943496618": "Thor",
            "image21943496617": "thor.png"
        }, {
            "label1943496616037": "$2.0",
            "label1943496618": "Avatar",
            "image21943496617": "avatar.png"
        }, {
            "label1943496616037": "$19.9",
            "label1943496618": "Big Hero 6",
            "image21943496617": "bighero.png"
        }, {
            "label1943496616037": "$3.6",
            "label1943496618": "Despicable Me 2",
            "image21943496617": "despicableme.png"
        }, {
            "label1943496616037": "$10.0",
            "label1943496618": "Furious7",
            "image21943496617": "furious7.png"
        }, {
            "label1943496616037": "$3.7",
            "label1943496618": "Hobbit",
            "image21943496617": "hobbit.png"
        }, {
            "label1943496616037": "$4.6",
            "label1943496618": "Interstellar",
            "image21943496617": "interstellar.png"
        }, {
            "label1943496616037": "$7.8",
            "label1943496618": "Jurassic Park",
            "image21943496617": "jurassicpark.png"
        }, {
            "label1943496616037": "$21.2",
            "label1943496618": "Hobbit (Blu Ray)",
            "image21943496617": "hobbit.png"
        }],
        "Location": "[1,191]",
        "rowTemplate": segment214170896410box,
        "rowSkin": "seg2Normal",
        "rowFocusSkin": "seg2Focus",
        "sectionHeaderSkin": "seg2Header",
        "separatorRequired": true,
        "separatorThickness": 1,
        "separatorColor": "64646400",
        "showScrollbars": false,
        "groupCells": false,
        "screenLevelWidget": false,
        "onRowClick": frmHome_segment214170896410_onRowClick_seq0,
        "selectionBehavior": constants.SEGUI_DEFAULT_BEHAVIOR,
        "viewType": constants.SEGUI_VIEW_TYPE_TABLEVIEW,
        "layoutType": null
    }, {
        "margin": [0, 10, 0, 0],
        "padding": [0, 0, 0, 0],
        "containerHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 34
    }, {
        "indicator": constants.SEGUI_ROW_SELECT,
        "enableDictionary": false,
        "showProgressIndicator": true,
        "progressIndicatorColor": constants.PROGRESS_INDICATOR_COLOR_WHITE,
        "bounces": true,
        "editStyle": constants.SEGUI_EDITING_STYLE_NONE
    });
    var image21943496617 = new kony.ui.Image2({
        "id": "image21943496617",
        "isVisible": true,
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "src": null
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "margin": [3, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "referenceWidth": null,
        "referenceHeight": null,
        "marginInPixel": false,
        "paddingInPixel": false,
        "containerWeight": 12
    }, {
        "glossyEffect": constants.IMAGE_GLOSSY_EFFECT_DEFAULT
    });
    var label1943496618 = new kony.ui.Label({
        "id": "label1943496618",
        "isVisible": true,
        "skin": "itemLabel"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [15, 1, 1, 1],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 40
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var label1943496616037 = new kony.ui.Label({
        "id": "label1943496616037",
        "isVisible": true,
        "skin": "lblNormal"
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [1, 1, 1, 1],
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 40
    }, {
        "textCopyable": false,
        "wrapping": constants.WIDGET_TEXT_WORD_WRAP
    });
    var hbox1943496616 = new kony.ui.Box({
        "id": "hbox1943496616",
        "isVisible": true,
        "position": constants.BOX_POSITION_AS_NORMAL,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL
    }, {
        "containerWeight": 34,
        "percent": true,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT,
        "margin": [0, 0, 0, 0],
        "padding": [0, 0, 0, 0],
        "vExpand": false,
        "marginInPixel": false,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {});
    hbox1943496616.add(
    image21943496617, label1943496618, label1943496616037);
    segment214170896410box.add(
    hbox1943496616);
    var button1417089648 = new kony.ui.Button({
        "id": "button1417089648",
        "isVisible": true,
        "text": "Checkout",
        "skin": "addToCartSkin",
        "focusSkin": "btnFocus",
        "onClick": frmHome_button1417089648_onClick_seq0
    }, {
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER,
        "vExpand": false,
        "hExpand": true,
        "margin": [1, 1, 1, 1],
        "padding": [0, 3, 0, 3],
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "marginInPixel": true,
        "paddingInPixel": false,
        "containerWeight": 6
    }, {
        "glowEffect": false,
        "showProgressIndicator": true
    });
    frmHome.add(
    hbox1943496612014, button16664216399, segment214170896410, button1417089648);
};

function frmHomeGlobals() {
    var MenuId = [];
    frmHome = new kony.ui.Form2({
        "id": "frmHome",
        "needAppMenu": true,
        "title": null,
        "enabledForIdleTimeout": false,
        "skin": "frm",
        "addWidgets": addWidgetsfrmHome
    }, {
        "padding": [0, 0, 0, 0],
        "displayOrientation": constants.FORM_DISPLAY_ORIENTATION_PORTRAIT,
        "paddingInPixel": false,
        "layoutType": constants.CONTAINER_LAYOUT_BOX
    }, {
        "retainScrollPosition": false,
        "needsIndicatorDuringPostShow": true,
        "formTransparencyDuringPostShow": "100",
        "inputAccessoryViewType": constants.FORM_INPUTACCESSORYVIEW_DEFAULT,
        "bounces": true,
        "configureExtendTop": false,
        "configureExtendBottom": false,
        "configureStatusBarStyle": false,
        "titleBar": true,
        "footerOverlap": false,
        "headerOverlap": false,
        "inTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        },
        "outTransitionConfig": {
            "transitionDirection": "none",
            "transitionEffect": "none"
        }
    });
};