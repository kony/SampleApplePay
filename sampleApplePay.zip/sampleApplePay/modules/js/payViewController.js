function encode_utf8(s) {
    return unescape(encodeURIComponent(s));
}

var addressGlobal;

function loadPayView(arg1, arg2, arg3) {
    var paymentNetworkTypes = [PKPaymentNetworkAmex, PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
    var PayViewController = objc.newClass('PayViewController', 'UIViewController', ['PKPaymentAuthorizationViewControllerDelegate'], {
        viewDidLoad: function() {
            kony.print("PayViewController viewDidLoad: " + PKPaymentAuthorizationViewController.canMakePayments());
            if ((PKPaymentAuthorizationViewController.canMakePayments())) {
                kony.print("This device is authorised to make Payments");
            } else {
                alert("This device is not authorised to make Payments");
                return;
            }
            if ((PKPaymentAuthorizationViewController.canMakePaymentsUsingNetworks(paymentNetworkTypes))) {
                kony.print("This device is authorised to make Payments on given networks");
            } else {
                alert("This device is not authorised to make Payments");
                return;
            }
            //subtotal = NSDecimalNumber.decimalNumberWithString("0.005");
            //shippingTotal = NSDecimalNumber.decimalNumberWithString("0.004");
            kony.print("shippingMethod1 :1");

            subTotal = NSDecimalNumber.decimalNumberWithString(subTotalStr.toFixed(2));
            shippingTotal = NSDecimalNumber.decimalNumberWithString(shippingTotalStr.toFixed(2));
            total = NSDecimalNumber.decimalNumberWithString(totalStr.toFixed(2));

            kony.print("shippingMethod1 :2");
            var request = PKPaymentRequest.alloc().jsinit();
            request.supportedNetworks = paymentNetworkTypes;
            request.countryCode = "US"
            request.currencyCode = "USD"
            request.merchantIdentifier = "merchant.com.kony.authorize.pay";
            request.merchantCapabilities = PKMerchantCapability3DS; //PKMerchantCapabilityEMV; ;
            //request.shippingAddress = 
            // Optional Apple Pay parameter - Send a sample application data payload
            // var appDataString = "RefCode:12345; TxID:34234089240982304823094823432";
            //var appData = NSData.alloc().initWithBase64Encoding(appDataString);
            kony.print("shippingMethod1 :2.1");
            //request.applicationData = appData;
            kony.print("shippingMethod1 :2.3");

/* var subtotalValue = NSDecimalNumber.decimalNumberWithString(subTotal);
                var shippingTotalValue = NSDecimalNumber.decimalNumberWithString(shippingTotal);
                var totalValue = NSDecimalNumber.decimalNumberWithString(total);*/
            var subtotalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Subtotal", subTotal);
            var shippingItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Shipping", shippingTotal);
            var totalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Total", total);
            var items = [subtotalItem, shippingItem, totalItem];
            request.paymentSummaryItems = items;


            request.requiredBillingAddressFields = PKAddressFieldAll;
            request.requiredShippingAddressFields = PKAddressFieldAll;
            //request.requiredShippingAddressFields = PKAddressFieldName;
            //var error = NSError.alloc().init();
            kony.print("shippingMethod1 :3" + addressGlobal);
            request.shippingAddress = addressGlobal;
            var shippingMethod1 = PKShippingMethod.alloc().jsinit();
            shippingMethod1.amount = NSDecimalNumber.decimalNumberWithString("0.05"); //$0.005
            shippingMethod1.label = "UPS";
            shippingMethod1.identifier = "UPS";
            shippingMethod1.detail = "3 Day Ground";
            kony.print("shippingMethod1 :4");

            var shippingMethod2 = PKShippingMethod.alloc().jsinit();
            kony.print("shippingMethod1 :5");

            shippingMethod2.amount = NSDecimalNumber.decimalNumberWithString("0.009"); //$0.009
            shippingMethod2.label = "USPS";
            shippingMethod2.identifier = "USPS";
            shippingMethod2.detail = "5-7 Days";
            var shippingMethods = [shippingMethod1, shippingMethod2];
            //request.shippingMethods = shippingMethods;
            kony.print("shippingMethod1 :" + shippingMethod1.amount);
            //Create the view controller that will show the user the Apple Pay screen.
            vc = PKPaymentAuthorizationViewController.alloc().initWithPaymentRequest(request);
            vc.delegate = this;
            //You may notice that PKPaymentAuthorizationViewController shows itself whether you
            //call this or not, but if you don't call it there will be unexpected behavior.
            UIApplication.sharedApplication().keyWindow.rootViewController.presentViewControllerAnimatedCompletion(vc, true, function() {
                kony.print("View Controller Shown")
            });
        },
        viewWillAppear: function(animated) {
            kony.print("viewWillappear");

            //this.presentViewControllerAnimatedCompletion(vc, true, null);
        },
        viewWillDisappear: function(animated) {
            kony.print("viewWillDisappear");
        },
        paymentAuthorizationViewControllerDidAuthorizePaymentCompletion: function(controller, payment, completion) {
            kony.print("paymentAuthorizationViewControllerDidAuthorizePaymentCompletion: " + controller);
            //The user approved the transaction.  Time to send the transaction to the Gateway
            //for authorization.
            kony.print("Payment was authorized"+payment.billingAddress);
            //Most merchants will want to send the transaction data to their own server before
            //forwarding to the Gateway so that you will have the transaction information and be
            //aware of whether the transaction succeeded.  For this simple example, though, we
            //will just added the login id and transaction key values in post processor..
            //Replace those with your own credentials
            if (payment.billingAddress != undefined && addressObjectBilling != undefined) {
            	kony.print("Payment was authorized");
                updateAddressObjectFromPKPaymentABRecord(addressObjectBilling, payment.billingAddress);
            }

            if (payment.shippingAddress != undefined && addressObjectShipping != undefined) {
                updateAddressObjectFromPKPaymentABRecord(addressObjectShipping, payment.shippingAddress)
            }
            // Since the Phone and Email is enabled only if we enable the Shipping, Just to use for the billing we do this.
            if (addressObjectBilling.phone == undefined) {
            	kony.print("Setting the phone number");
                addressObjectBilling.phone = addressObjectShipping.phone;
            }
            if (addressObjectBilling.email == undefined) {
            	kony.print("Setting the email");
                addressObjectBilling.email = addressObjectShipping.email;
            }
            //paymentData is an NSData object.  It needs to be converted to a hex string to be able
            //to send it to the Gateway.
            var dataReturned = payment.token.paymentData;
            kony.print("Sending data to Gateway: %@ " + dataReturned.base64Encoding());
            sendPaymentRequest(dataReturned.base64Encoding(), completion);
            //Keep the completion callback function.
            //Once we get a response from the server, we'll use it to report success or failure back
            //to PassKit.
            //this.completionCallback = completion;
        },

        paymentAuthorizationViewControllerDidFinish: function(controller) {
            kony.print("paymentAuthorizationViewControllerDidFinish: " + controller);
            //This message is sent when the payment authorization form disappears, either after
            //the user cancels or after the payment is completed.
            UIApplication.sharedApplication().keyWindow.rootViewController.dismissViewControllerAnimatedCompletion(true, function() {
                kony.print("View Controller Dismissed")
            });
        },

        paymentAuthorizationViewControllerDidSelectShippingMethodCompletion: function(controller, shippingmethod, completion) {
            kony.print("paymentAuthorizationViewControllerDidSelectShippingMethodCompletion");
            //This message is sent when the user changes their shipping method.
            //This is an opportunity to recalculate the total.
            kony.print("Shipping method changed to: " + shippingmethod.identifier);
            kony.print("subTotalStr is : " + subTotalStr);
            subTotal = NSDecimalNumber.decimalNumberWithString(subTotalStr);
            var methodShippingTotal = "0";
            if (shippingmethod.identifier == "UPS") {
                kony.print("shippingTotal is : IF");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.03");
            } else if (shippingmethod.identifier == "USPS") {
                kony.print("shippingTotal is : ELSE IF");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.01");
            } else {
                kony.print("shippingTotal is : ELSE");
                methodShippingTotal = NSDecimalNumber.decimalNumberWithString("0.06");
            }
            kony.print("methodShippingTotal is : " + methodShippingTotal.stringValue);
            //sssss.decimalNumberByAdding(shippingTotal);
            //subtotal.decimalNumberByAdding(shippingTotal);
            //Add up the shipping and subtotal to get the amount that will be charged.
            total = subTotal.decimalNumberByAdding(methodShippingTotal);
            kony.print("total is : " + total.stringValue);
            var subtotalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Subtotal", subTotal);
            var shippingItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Shipping", methodShippingTotal);
            var totalItem = PKPaymentSummaryItem.summaryItemWithLabelAmount("Total", total);
            //var summaryItems = NSMutableArray.arrayWithObjects(subtotalItem,shippingItem,totalItem, null);
            var summaryItems = [subtotalItem, shippingItem, totalItem];
            //Pass the new summary items back to the controller using the completion function.
            completion(PKPaymentAuthorizationStatusSuccess, summaryItems);
            kony.print("Completion is invoked :" + summaryItems[0].amount.stringValue);

        }

/*, paymentAuthorizationViewControllerDidSelectShippingAddressCompletion: function(controller, address, completion) {
    		// The customer is selecting the shipping address information.
    		// You may need to keep track of the new shipping address.
    		kony.print(".....ViewController:didSelectShippingAddress invoked");
    		//kony.print(address);
		}*/
    });

    payViewController = PayViewController.jsnew();
    var x = payViewController.view;
}

function createAndGetContact() {
    kony.print("1");
    var addressBook = KonyAddressBookWrapper.ABAddressBookCreate(); // create address book record
    kony.print("2" + addressBook);
    //var x = [MyAddressBookExternalChangeCallback, this];
    var context = [1, 2, 3];
    KonyAddressBookWrapper.ABAddressBookRequestAccessWithCompletionCompletion(addressBook, function auth(bool, error) {
        kony.print("auth");
        kony.print(bool);
        person = KonyAddressBookWrapper.ABPersonCreate(); // create a person
        kony.print(person);


/* var request = PKPaymentRequest.alloc().jsinit();
                          request.supportedNetworks = [PKPaymentNetworkAmex, PKPaymentNetworkMasterCard, PKPaymentNetworkVisa];
                          request.countryCode = "US"
                          request.currencyCode = "USD"
                          request.merchantIdentifier = "merchant.com.kony.applepay";
                          request.merchantCapabilities = PKMerchantCapability3DS;
 
                          
                          request.requiredBillingAddressFields = PKAddressFieldAll;
                          request.requiredShippingAddressFields = PKAddressFieldAll;
                          var shippingMethod1 = PKShippingMethod.alloc().jsinit();
                          shippingMethod1.amount = NSDecimalNumber.decimalNumberWithString("0.005"); //$0.005
                          shippingMethod1.label = "UPS";
                          
                          print("Shipping address");
                          print(request.shippingAddress);*/
        var phone = "0123456788"; // the phone number to add
        var firstname = "Venkat";
        var lastname = "Saddala";

        KonyAddressBookWrapper.ABRecordSetValuePropertyValueError(person, kABPersonFirstNameProperty, firstname, null);
        KonyAddressBookWrapper.ABRecordSetValuePropertyValueError(person, kABPersonLastNameProperty, lastname, null);
        var x;
        var addRec = KonyAddressBookWrapper.ABAddressBookAddRecordRecordError(addressBook, person, null); //add the new person to the record
        var saveRec = KonyAddressBookWrapper.ABAddressBookSaveError(addressBook, null); //save the record
        kony.print("4" + addRec);

        // request.shippingAddress = person;
        var recId = KonyAddressBookWrapper.ABRecordGetRecordID(person);
        kony.print(recId);

        var recType = KonyAddressBookWrapper.ABRecordGetRecordType(addRec);
        kony.print("5" + recType);
        var phoneNumberMultiValue = KonyAddressBookWrapper.ABMultiValueCreateMutable(2);
        addressGlobal = person;
        kony.print("5" + addressGlobal);
        //var phone = "990983333";
/*var outprop = 100;
      KonyAddressBookWrapper.ABMultiValueAddValueAndLabelValueLabelOutIdentifier(phoneNumberMultiValue,phone,kABPersonPhoneMobileLabel,outprop);
      print("Venkat");
      print(outprop);*/
    });
}


function completionCallback(status) {
    kony.print("Status: " + status);
}