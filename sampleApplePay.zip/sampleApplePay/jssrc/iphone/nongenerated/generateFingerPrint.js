//GlobalSequences File
var callbackCompletionRes = null;

function sendPaymentRequest(nameStr, dataValueStr, completionBlock) {
    var params = {};
    kony.print("****************nameStr" + nameStr);
    params["appID"] = "sampleApplePay";
    params["serviceID"] = "TestSer";
    params["channel"] = "rc";
    params["nameStr"] = nameStr;
    params["dataValueStr"] = dataValueStr;
    params["hashValueStr"] = "none2";
    params["seq"] = "none3";
    params["stamp"] = "none4";
    //Below 5 input parameters should be in an array. In real time scenarios, customers can select array of items.
    params["itemIdVar"] = "Item1ID";
    params["nameVar"] = "Item1";
    params["descVar"] = "Item1 Description";
    params["quantityVar"] = 1;
    params["unitPriceVar"] = 0.02;
    params["billFirstName"] = addressObjectBilling.firstName
    params["billLastName"] = addressObjectBilling.lastName
    params["billAddress"] = addressObjectBilling.street1
    params["billCity"] = addressObjectBilling.city
    params["billState"] = addressObjectBilling.state
    params["billZip"] = addressObjectBilling.zip
    params["billCountry"] = addressObjectBilling.country
    params["billPhoneNumber"] = addressObjectBilling.phone
    params["shipFirstName"] = addressObjectShipping.firstName;
    params["shipLastName"] = addressObjectShipping.lastName
    params["shipAddress"] = addressObjectShipping.street1
    params["shipCity"] = addressObjectShipping.city
    params["shipState"] = addressObjectShipping.state
    params["shipZip"] = addressObjectShipping.zip
    params["shipCountry"] = addressObjectShipping.country
    params["amountStr"] = "0.02";
    params["platform"] = kony.os.deviceInfo().name;
    params["httpheaders"] = {
        "Content-Type": "text/xml"
    };
    var url = "http://10.10.12.212:8080/middleware/MWServlet";
    var vv = kony.net.invokeServiceAsync(url, params, asyncCallback);
    kony.print("****************dataValueStr" + dataValueStr);
    callbackCompletionRes = completionBlock;
};

function asyncCallback(status, resulttable) {
    kony.print("****************status" + status);
    kony.print("**************result opstatus table:" + resulttable["opstatus"]);
    kony.print("**************result errmsg table:" + resulttable["errmsg"]);
    if (status == 400) {
        if (resulttable["opstatus"] == 0) {
            kony.print("$#." + JSON.stringify(resulttable));
            kony.print("Result Received");
            callbackCompletionRes(PKPaymentAuthorizationStatusSuccess);
        }
    }
}