window = UIWindow.jsnew();
window.frame = UIScreen.mainScreen().bounds;
window.backgroundColor = UIColor.whiteColor();

function loadSampleView(arg1, arg2, arg3) {
    kony.print("loadSampleView");
    var SampleViewController = objc.newClass('SampleViewController', 'UIViewController', [], {
        viewDidLoad: function() {
            kony.print("SampleViewController viewDidLoad");
            viewController = UIViewController.jsnew();
            kony.print("viewController: " + viewController);
            var viewFrame = {
                x: 20,
                y: 20,
                width: this.view.bounds.width - (20 * 2),
                height: 30
            };
            viewController.view.frame = viewFrame;
            var label = UILabel.alloc().initWithFrame(viewFrame);
            label.text = "Contained View Controller's View";
            kony.print("label: " + label);
            viewController.view.addSubview(label);
            //viewController.delegate = this;
            // this.presentViewControllerAnimatedCompletion(viewController, true, null);
        },
        viewDidAppear: function(animated) {
            kony.print("viewDidAppear");
            viewController.dismissViewControllerAnimatedCompletion(true, null);
        },
        viewDidDisappear: function(animated) {}
    });
    var sampleViewController = SampleViewController.jsnew();
    window.rootViewController = sampleViewController;
    window.makeKeyAndVisible();
    kony.print("sampleViewController: " + sampleViewController);
    sampleViewController.presentViewControllerAnimatedCompletion(viewController, true, null);
    //UIAlertView.alloc().initWithTitleMessageDelegateCancelButtonTitleOtherButtonTitles('Hello, World', 'Varargs!', null, 'Cancel', ['OK']).show()
}