//Form JS File
function frmDetails_button1943496612937_onClick_seq0(eventobject) {
    addToCart.call(this, null, null, null, null);
};

function frmDetails_button1417089648_onClick_seq0(eventobject) {
    checkout.call(this);
};

function addWidgetsfrmDetails() {
    var itemName = new kony.ui.Label({
        "id": "itemName",
        "isVisible": true,
        "skin": "lblNormal",
        "text": "Label"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var itemImage = new kony.ui.Image2({
        "id": "itemImage",
        "imageWhenFailed": null,
        "imageWhileDownloading": null,
        "isVisible": true,
        "src": null
    }, {
        "containerWeight": 44,
        "imageScaleMode": constants.IMAGE_SCALE_MODE_MAINTAIN_ASPECT_RATIO,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "referenceHeight": null,
        "referenceWidth": null,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var itemPrice = new kony.ui.Label({
        "id": "itemPrice",
        "isVisible": true,
        "skin": "lblNormal",
        "text": "Label"
    }, {
        "containerWeight": 40,
        "contentAlignment": constants.CONTENT_ALIGN_MIDDLE_LEFT,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [1, 1, 1, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {
        "textCopyable": false
    });
    var hbox1943496616426 = new kony.ui.Box({
        "id": "hbox1943496616426",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 11,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    hbox1943496616426.add(
    itemImage, itemPrice);
    var itemQuantity = new kony.ui.ComboBox({
        "focusSkin": "cboxFocus",
        "id": "itemQuantity",
        "isVisible": true,
        "masterData": [
            ["1", "1"],
            ["2", "2"],
            ["3", "3"],
            ["4", "4"],
            ["5", "5"]
        ],
        "skin": "cboxNormal"
    }, {
        "containerWeight": 40,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 1, 0, 1],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var hbox1943496614634 = new kony.ui.Box({
        "id": "hbox1943496614634",
        "isVisible": true,
        "orientation": constants.BOX_LAYOUT_HORIZONTAL,
        "position": constants.BOX_POSITION_AS_NORMAL
    }, {
        "containerWeight": 11,
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false,
        "percent": true,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_TOP_LEFT
    }, {});
    hbox1943496614634.add(
    itemQuantity);
    var button1943496612937 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1943496612937",
        "isVisible": true,
        "onClick": frmDetails_button1943496612937_onClick_seq0,
        "skin": "addToCartSkin",
        "text": "Add To Cart"
    }, {
        "containerWeight": 5,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    var button1417089648 = new kony.ui.Button({
        "focusSkin": "btnFocus",
        "id": "button1417089648",
        "isVisible": true,
        "onClick": frmDetails_button1417089648_onClick_seq0,
        "skin": "addToCartSkin",
        "text": "Checkout"
    }, {
        "containerWeight": 6,
        "contentAlignment": constants.CONTENT_ALIGN_CENTER,
        "displayText": true,
        "hExpand": true,
        "margin": [0, 0, 0, 0],
        "marginInPixel": false,
        "padding": [0, 3, 0, 3],
        "paddingInPixel": false,
        "vExpand": false,
        "widgetAlignment": constants.WIDGET_ALIGN_CENTER
    }, {});
    frmDetails.add(
    itemName, hbox1943496616426, hbox1943496614634, button1943496612937, button1417089648);
};

function frmDetailsGlobals() {
    var MenuId = [];
    frmDetails = new kony.ui.Form2({
        "addWidgets": addWidgetsfrmDetails,
        "enabledForIdleTimeout": false,
        "id": "frmDetails",
        "needAppMenu": true,
        "skin": "frm",
        "title": null
    }, {
        "layoutType": constants.CONTAINER_LAYOUT_BOX,
        "padding": [0, 0, 0, 0],
        "paddingInPixel": false
    }, {
        "inTransitionConfig": {
            "formTransition": "None"
        },
        "outTransitionConfig": {
            "formTransition": "None"
        },
        "retainScrollPosition": false
    });
};