var addressObjectBilling = {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    street1: "",
    city: "",
    state: "",
    zip: "",
    country: ""
};

var addressObjectShipping = {
    firstName: "",
    lastName: "",
    email: "",
    phone: "",
    street1: "",
    city: "",
    state: "",
    zip: "",
    country: ""
};

function updateAddressObjectFromPKPaymentABRecord(addressObj, paymentABRecord) {
    kony.print("Payment was authorized update" + paymentABRecord);
    if (paymentABRecord != undefined && addressObj != undefined) {
        kony.print("Payment was authorized for prop: " + kABPersonFirstNameProperty);
        //kony.print("Payment was authorized"+KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, kABPersonFirstNameProperty));
        addressObj.firstName = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, kABPersonFirstNameProperty);
        addressObj.lastName = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, kABPersonLastNameProperty);

        kony.print("First name:" + addressObj.firstName);
        kony.print("lastName :" + addressObj.lastName);
        for (var i = 0; i < 18; i++) {
            var email = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, i);

            kony.print("emails :" + i + ": " + email);
        }
        var emails = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, 13);
        //var emails2 = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, 5);
        //var phoneNumbers = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, kABPersonPhoneProperty);

        if (KonyAddressBookWrapper.ABMultiValueGetCount(emails) > 0) {
            kony.print("Payment was authorized with emails count: " + KonyAddressBookWrapper.ABMultiValueGetCount(emails));

            for (var i = 0; i < KonyAddressBookWrapper.ABMultiValueGetCount(emails); i++) {
                kony.print("Payment was authorized inside 1: ");
                var label = KonyAddressBookWrapper.ABMultiValueCopyLabelAtIndexIndex(emails, i);
                kony.print("Payment was authorized inside 2: " + label);
                var value = KonyAddressBookWrapper.ABMultiValueCopyValueAtIndexIndex(emails, i);
                addressObj.email = value;
                kony.print("Payment was authorized inside 3: " + value);
            }
        }
        kony.print("In Mobile Section");
        var phoneNumbers = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, 3);
kony.print("In Mobile Section 2: "+phoneNumbers);
        if (KonyAddressBookWrapper.ABMultiValueGetCount(phoneNumbers) > 0) {
        kony.print("In Mobile Section 3: "+KonyAddressBookWrapper.ABMultiValueGetCount(phoneNumbers));
            for (var i = 0; i < KonyAddressBookWrapper.ABMultiValueGetCount(phoneNumbers); i++) {
                var label = KonyAddressBookWrapper.ABMultiValueCopyLabelAtIndexIndex(phoneNumbers, i);
                var value = KonyAddressBookWrapper.ABMultiValueCopyValueAtIndexIndex(phoneNumbers, i);
                addressObj.phone = value;
            }
        }
        kony.print("Street Address was authorized");
        var streetAddress = KonyAddressBookWrapper.ABRecordCopyValueProperty(paymentABRecord, 5);
        if (KonyAddressBookWrapper.ABMultiValueGetCount(streetAddress) > 0) {
            var theDict = KonyAddressBookWrapper.ABMultiValueCopyValueAtIndexIndex(streetAddress, 0);
            kony.print("Street Address theDict: "+theDict.City);
           /* addressObj.street1 = theDict.objectForKey(kABPersonAddressStreetKey);
            addressObj.city = theDict.objectForKey(kABPersonAddressCityKey);
            addressObj.state = theDict.objectForKey(kABPersonAddressStateKey);
            addressObj.zip = theDict.objectForKey(kABPersonAddressZIPKey);
            addressObj.country = theDict.objectForKey(kABPersonAddressCountryKey);*/
            addressObj.street1 = theDict.Street;
            addressObj.city = theDict.City;
            addressObj.state = theDict.State;
            addressObj.zip = theDict.ZIP;
            addressObj.country = theDict.Country;
        }
    } else {
        kony.print("Invalid Params");
    }
    kony.print("::::::::::addressObjectBilling: " + JSON.stringify(addressObjectBilling));
    kony.print("::::::::::addressObjectShipping: " + JSON.stringify(addressObjectShipping));
}